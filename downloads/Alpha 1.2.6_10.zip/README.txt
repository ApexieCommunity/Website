This is a MultiMC/PolyMC instance to import.

How to play this version? Download one of the two mentioned programs (PolyMC is recommended), then open it
and drag in this .zip file. After that, make sure you have JDK 8 installed, then open it.
When the game is opened, paste in your preview key generated using the website and you have successfully
installed Alpha 1.2.6_10. This is the first preview version that I found so make sure you subscribe to my
channel, so once I've found a new preview version, you'll be notified for it.